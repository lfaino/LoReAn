## Problem description


## Exact command line call triggering the problem

```
gt ...
```

## Example minimal input triggering the problem


## What GenomeTools version are you reporting an issue for (as output by `gt -version`)?


## Did you compile GenomeTools from source? If so, please state the `make` parameters used.


## What operating system (e.g. Ubuntu, Mac OS X), OS version (e.g. 15.10, 10.11) and platform (e.g. x86_64) are you using?
