if not gtdata_doc_dir then gtdata_doc_dir = "./" end
dofile(gtdata_doc_dir.."regionmapping.lua")
