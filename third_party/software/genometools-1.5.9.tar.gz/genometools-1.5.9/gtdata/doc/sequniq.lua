print ([[

The tool will only remove identical duplicates of sequences, not substrings
contained within other sequences.]])
