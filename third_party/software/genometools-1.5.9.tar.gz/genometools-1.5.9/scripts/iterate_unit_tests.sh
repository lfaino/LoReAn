#!/bin/sh -e

while true
do
  bin/gt -debug -test
done
